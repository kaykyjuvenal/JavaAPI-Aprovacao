package br.edu.ifsp.pw3.api.mecanico;

public record DadosMecanico(String nome, String anos_experiencia) {

}
