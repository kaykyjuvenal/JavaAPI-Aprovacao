package br.edu.ifsp.pw3.api.conserto;

import org.springframework.data.jpa.repository.JpaRepository;
import br.edu.ifsp.pw3.api.conserto.Conserto;

public interface ConsertoRepository extends JpaRepository<Conserto, Long> {

}

