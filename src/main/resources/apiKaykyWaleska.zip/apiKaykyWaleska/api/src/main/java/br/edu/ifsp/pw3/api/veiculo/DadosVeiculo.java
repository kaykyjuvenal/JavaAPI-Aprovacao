package br.edu.ifsp.pw3.api.veiculo;


public record DadosVeiculo(String marca, String modelo, String ano) {

}
